package com.example.luckywheel

import android.animation.Animator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("lucky_wheel_native", Context.MODE_PRIVATE) }
    private val rng = SecureRandom()
    private val names = mutableListOf<String>()
    private val history = mutableListOf<HistoryEntry>()
    private val prizes = mutableListOf("جایزه نفر اول", "جایزه نفر دوم", "جایزه نفر سوم")
    private val rewards = mutableListOf("", "", "")
    private var wheelAngle = 0f
    private var spinning = false
    private var removeWinner = true
    private var spinRounds = 8
    private var spinDuration = 5200
    private var forcedWinner: String? = null
    private var themeChoice = 0
    private var vibrationEnabled = true
    private var confettiEnabled = true
    private var rounds = 0

    private lateinit var root: LinearLayout
    private lateinit var nameInput: EditText
    private lateinit var wheelView: WheelView
    private lateinit var spinButton: Button
    private lateinit var resultText: TextView
    private lateinit var statusText: TextView
    private lateinit var winnerCountInput: EditText
    private lateinit var prizeInputs: List<EditText>
    private lateinit var rewardInputs: List<EditText>
    private lateinit var statsText: TextView

    private val accent: Int
        get() = when (themeChoice) {
            1 -> 0xFF25C2A0.toInt()
            2 -> 0xFFFF8C42.toInt()
            3 -> 0xFFFF5D9E.toInt()
            else -> 0xFF8B72FF.toInt()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF101225.toInt()
        window.navigationBarColor = 0xFF101225.toInt()
        loadData()
        buildUi()
        refreshUi()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0B0D1B.toInt())
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFF14172B.toInt())
        }
        val menu = Button(this).apply {
            text = "☰"
            textSize = 22f
            setTextColor(-1)
            setBackgroundColor(0xFF282D49.toInt())
            minWidth = dp(48)
            setOnClickListener { showMainMenu(it) }
        }
        val titleColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        titleColumn.addView(label("گردونه شانس", 21f, -1, true))
        titleColumn.addView(label("نسخه بومی اندروید · بدون اینترنت", 11f, 0xFFADB5D4.toInt()))
        top.addView(menu, LinearLayout.LayoutParams(dp(48), dp(48)))
        top.addView(titleColumn, LinearLayout.LayoutParams(0, -2, 1f))
        val saved = label("● ذخیره خودکار", 10f, 0xFF69E6B2.toInt())
        top.addView(saved)
        root.addView(top)

        val scroll = ScrollView(this).apply { fillViewport = true }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(24))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val wheelCard = card()
        wheelCard.addView(sectionTitle("🎡  گردونه قرعه‌کشی"))
        statusText = label("اسم‌ها را وارد کن و قرعه‌کشی را شروع کن.", 12f, 0xFFADB5D4.toInt()).apply {
            setPadding(0, dp(5), 0, dp(8))
        }
        wheelCard.addView(statusText)
        val wheelFrame = FrameLayout(this)
        wheelView = WheelView(this)
        wheelFrame.addView(wheelView, FrameLayout.LayoutParams(-1, -1))
        val center = Button(this).apply {
            text = "✦\nقرعه‌کشی"
            textSize = 14f
            setTextColor(0xFF2B1B28.toInt())
            typeface = Typeface.DEFAULT_BOLD
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(0xFFFFCA61.toInt())
                setStroke(dp(5), 0xFFFFF0B7.toInt())
            }
            elevation = dp(8).toFloat()
            setOnClickListener { spinSingle() }
        }
        wheelFrame.addView(center, FrameLayout.LayoutParams(dp(92), dp(92), Gravity.CENTER))
        spinButton = center
        wheelCard.addView(wheelFrame, LinearLayout.LayoutParams(-1, dp(340)))
        val wheelActions = horizontalRow()
        wheelActions.addView(button("🎲 شروع قرعه‌کشی", accent) { spinSingle() }, weighted())
        wheelActions.addView(button("🏆 انتخاب چند رتبه", 0xFF29304D.toInt()) { spinRanked() }, weighted())
        wheelCard.addView(wheelActions)
        resultText = label("نتیجه قرعه‌کشی اینجا نمایش داده می‌شود.", 14f, 0xFFF5F6FF.toInt(), true).apply {
            setPadding(dp(12), dp(13), dp(12), dp(13))
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF20233C.toInt())
        }
        val resultParams = LinearLayout.LayoutParams(-1, -2)
        resultParams.topMargin = dp(12)
        wheelCard.addView(resultText, resultParams)
        content.addView(wheelCard)

        val peopleCard = card()
        peopleCard.addView(sectionTitle("👥  شرکت‌کننده‌ها"))
        peopleCard.addView(label("هر اسم را در یک خط بنویس. اسم‌های تکراری حذف می‌شوند.", 11f, 0xFFADB5D4.toInt()))
        nameInput = EditText(this).apply {
            hint = "امیر\nعلی\nسارا\nمحمد"
            setTextColor(-1); setHintTextColor(0xFF737C9F.toInt())
            textSize = 14f; gravity = Gravity.TOP or Gravity.RIGHT
            minLines = 4; maxLines = 10
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(0xFF101327.toInt(), 0xFF343B5D.toInt(), 12)
            setText(names.joinToString("\n"))
        }
        val nameParams = LinearLayout.LayoutParams(-1, dp(145)); nameParams.topMargin = dp(10)
        peopleCard.addView(nameInput, nameParams)
        val peopleActions = horizontalRow()
        peopleActions.addView(button("✓ ثبت اسم‌ها", accent) { syncNames() }, weighted())
        peopleActions.addView(button("⤨ درهم‌ریزی", 0xFF29304D.toInt()) {
            syncNames(false)
            for (i in names.lastIndex downTo 1) {
                val j = rng.nextInt(i + 1)
                val tmp = names[i]; names[i] = names[j]; names[j] = tmp
            }
            nameInput.setText(names.joinToString("\n"))
            saveData(); refreshUi(); toast("ترتیب اسم‌ها عوض شد.")
        }, weighted())
        peopleCard.addView(peopleActions)
        val removeCheck = CheckBox(this).apply {
            text = "برنده بعد از انتخاب از دور بعد حذف شود"
            textSize = 12f; setTextColor(0xFFDCE0FA.toInt()); isChecked = removeWinner
            buttonTintList = android.content.res.ColorStateList.valueOf(accent)
            setOnCheckedChangeListener { _, checked -> removeWinner = checked; saveData() }
        }
        peopleCard.addView(removeCheck)
        statsText = label("", 11f, 0xFF62D9F3.toInt()).apply { setPadding(0, dp(7), 0, 0) }
        peopleCard.addView(statsText)
        content.addView(peopleCard)

        val prizeCard = card()
        prizeCard.addView(sectionTitle("🎁  جایزه رتبه‌ها"))
        val pList = mutableListOf<EditText>()
        val rList = mutableListOf<EditText>()
        for (i in 0..2) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            }
            val rank = label(listOf("🥇", "🥈", "🥉")[i], 19f, -1, true).apply { gravity = Gravity.CENTER }
            row.addView(rank, LinearLayout.LayoutParams(dp(40), dp(48)))
            val p = EditText(this).apply {
                setSingleLine(true); textSize = 12f; setTextColor(-1); setHintTextColor(0xFF737C9F.toInt())
                hint = "عنوان رتبه ${i + 1}"; setText(prizes[i])
                background = rounded(0xFF101327.toInt(), 0xFF343B5D.toInt(), 10)
                setPadding(dp(8), dp(6), dp(8), dp(6))
            }
            val r = EditText(this).apply {
                setSingleLine(true); textSize = 12f; setTextColor(-1); setHintTextColor(0xFF737C9F.toInt())
                hint = "نام جایزه"; setText(rewards[i])
                background = rounded(0xFF101327.toInt(), 0xFF343B5D.toInt(), 10)
                setPadding(dp(8), dp(6), dp(8), dp(6))
            }
            val lp = LinearLayout.LayoutParams(0, dp(46), 1f); lp.marginEnd = dp(6)
            row.addView(p, lp)
            row.addView(r, LinearLayout.LayoutParams(0, dp(46), 1f))
            val rowParams = LinearLayout.LayoutParams(-1, -2); rowParams.topMargin = dp(7)
            prizeCard.addView(row, rowParams); pList.add(p); rList.add(r)
        }
        prizeInputs = pList; rewardInputs = rList
        prizeCard.addView(label("جایزه‌ها و عنوان رتبه‌ها هنگام ثبت نتیجه ذخیره می‌شوند.", 11f, 0xFFADB5D4.toInt()).apply {
            setPadding(0, dp(9), 0, dp(2))
        })
        val countRow = horizontalRow()
        winnerCountInput = EditText(this).apply {
            setText("3"); inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(-1); textSize = 14f; gravity = Gravity.CENTER
            background = rounded(0xFF101327.toInt(), 0xFF343B5D.toInt(), 10)
            hint = "تعداد برنده"; setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        countRow.addView(winnerCountInput, LinearLayout.LayoutParams(dp(90), dp(46)))
        countRow.addView(button("🏆 قرعه‌کشی رتبه‌ها", 0xFFFFB94E.toInt()) { spinRanked() }, weighted())
        prizeCard.addView(countRow)
        content.addView(prizeCard)

        val historyCard = card()
        val historyHeader = horizontalRow()
        historyHeader.addView(sectionTitle("📜  تاریخچه برندگان"), LinearLayout.LayoutParams(0, -2, 1f))
        historyHeader.addView(button("خروجی CSV", 0xFF29304D.toInt()) { exportCsv() })
        historyHeader.addView(button("پاک‌کردن", 0xFF492637.toInt()) { clearHistory() })
        historyCard.addView(historyHeader)
        val historyScroll = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        historyScroll.tag = "historyContainer"
        historyCard.addView(historyScroll)
        content.addView(historyCard)

        setContentView(root)
        renderHistory()
    }

    private fun showMainMenu(anchor: View) {
        PopupMenu(this, anchor).apply {
            menu.add("⚙ تنظیمات و شخصی‌سازی")
            menu.add("🎯 تعیین برنده از قبل")
            menu.add("📜 تاریخچه کامل")
            menu.add("💾 خروجی پشتیبان")
            menu.add("ℹ درباره برنامه")
            setOnMenuItemClickListener {
                when (it.title.toString()) {
                    "⚙ تنظیمات و شخصی‌سازی" -> showSettings()
                    "🎯 تعیین برنده از قبل" -> chooseForcedWinner()
                    "📜 تاریخچه کامل" -> showHistoryDialog()
                    "💾 خروجی پشتیبان" -> exportCsv()
                    else -> AlertDialog.Builder(this@MainActivity).setTitle("گردونه شانس")
                        .setMessage("نسخه بومی اندروید، آفلاین و با ذخیره‌سازی محلی. نتیجه قرعه‌کشی در تاریخچه ثبت می‌شود.")
                        .setPositiveButton("باشه", null).show()
                }
                true
            }
            show()
        }
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        box.addView(label("شخصی‌سازی گردونه", 18f, -1, true))
        box.addView(label("تعداد دور کامل انیمیشن", 12f, 0xFFADB5D4.toInt()).apply { setPadding(0, dp(14), 0, 0) })
        val roundsSeek = SeekBar(this).apply { max = 17; progress = spinRounds - 3 }
        box.addView(roundsSeek)
        val roundsLabel = label("$spinRounds دور", 12f, accent)
        box.addView(roundsLabel)
        roundsSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { roundsLabel.text = "${progress + 3} دور" }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        box.addView(label("مدت چرخش", 12f, 0xFFADB5D4.toInt()).apply { setPadding(0, dp(10), 0, 0) })
        val durationSeek = SeekBar(this).apply { max = 10; progress = ((spinDuration - 2500) / 1000).coerceIn(0, 10) }
        box.addView(durationSeek)
        val durationLabel = label("${spinDuration / 1000.0} ثانیه", 12f, accent)
        box.addView(durationLabel)
        durationSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                durationLabel.text = "${(2500 + progress * 1000) / 1000.0} ثانیه"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        box.addView(label("رنگ‌بندی", 12f, 0xFFADB5D4.toInt()).apply { setPadding(0, dp(10), 0, 0) })
        val themeSpinner = Spinner(this)
        themeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("بنفش", "فیروزه‌ای", "نارنجی", "صورتی"))
        themeSpinner.setSelection(themeChoice.coerceIn(0, 3))
        box.addView(themeSpinner)
        val vib = CheckBox(this).apply { text = "لرزش هنگام نتیجه"; setTextColor(-1); isChecked = vibrationEnabled }
        val conf = CheckBox(this).apply { text = "جلوه تبریک"; setTextColor(-1); isChecked = confettiEnabled }
        box.addView(vib); box.addView(conf)
        AlertDialog.Builder(this).setTitle("تنظیمات و شخصی‌سازی")
            .setView(box)
            .setNegativeButton("انصراف", null)
            .setPositiveButton("ذخیره") { _, _ ->
                spinRounds = roundsSeek.progress + 3
                spinDuration = 2500 + durationSeek.progress * 1000
                themeChoice = themeSpinner.selectedItemPosition
                vibrationEnabled = vib.isChecked
                confettiEnabled = conf.isChecked
                saveData(); refreshUi(); toast("تنظیمات ذخیره شد.")
            }.show()
    }

    private fun chooseForcedWinner() {
        syncNames(false)
        if (names.isEmpty()) { toast("اول اسم شرکت‌کننده‌ها را وارد کن."); return }
        val options = arrayOf("قرعه‌کشی کاملاً تصادفی") + names.toTypedArray()
        val selected = forcedWinner?.let { names.indexOf(it) + 1 }?.takeIf { it > 0 } ?: 0
        AlertDialog.Builder(this).setTitle("تعیین برنده از قبل")
            .setSingleChoiceItems(options, selected) { dialog, which ->
                forcedWinner = if (which == 0) null else names[which - 1]
                saveData()
                statusText.text = if (forcedWinner == null) "حالت تصادفی فعال است." else "🎯 برنده از قبل تعیین شده: $forcedWinner"
                dialog.dismiss()
                toast(if (forcedWinner == null) "حالت تصادفی فعال شد." else "برنده از قبل تعیین شد.")
            }
            .setNegativeButton("بستن", null).show()
    }

    private fun syncNames(showToast: Boolean = true) {
        val parsed = nameInput.text.toString().split(Regex("\\r?\\n")).map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        names.clear(); names.addAll(parsed)
        nameInput.setText(names.joinToString("\n"))
        if (forcedWinner !in names) forcedWinner = null
        saveData(); refreshUi()
        if (showToast) toast("${names.size} شرکت‌کننده ثبت شد.")
    }

    private fun spinSingle() {
        if (spinning) return
        syncNames(false)
        if (names.isEmpty()) { toast("اول اسم شرکت‌کننده‌ها را وارد کن."); return }
        capturePrizes()
        val chosen = forcedWinner?.takeIf { it in names } ?: names[rng.nextInt(names.size)]
        animateToWinner(chosen) {
            addHistory(chosen, 1, rewards[0].ifBlank { prizes[0] })
            resultText.text = "🏆 برنده: $chosen\n🎁 ${rewards[0].ifBlank { prizes[0] }}"
            if (removeWinner) { names.remove(chosen); nameInput.setText(names.joinToString("\n")) }
            forcedWinner = null
            afterWin()
        }
    }

    private fun spinRanked() {
        if (spinning) return
        syncNames(false)
        if (names.isEmpty()) { toast("اول اسم شرکت‌کننده‌ها را وارد کن."); return }
        capturePrizes()
        val count = winnerCountInput.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 3
        if (count > names.size) { toast("تعداد برنده‌ها از تعداد شرکت‌کننده‌ها بیشتر است."); return }
        val pool = names.toMutableList()
        val selected = mutableListOf<String>()
        val preset = forcedWinner
        if (preset != null && preset in pool) {
            selected.add(preset)
            pool.remove(preset)
        }
        while (selected.size < count) selected.add(pool.removeAt(rng.nextInt(pool.size)))
        animateToWinner(selected.first()) {
            selected.forEachIndexed { i, winner ->
                val prize = rewards.getOrNull(i).orEmpty().ifBlank { prizes.getOrNull(i).orEmpty().ifBlank { "رتبه ${i + 1}" } }
                addHistory(winner, i + 1, prize)
            }
            resultText.text = selected.mapIndexed { i, n ->
                "${listOf("🥇", "🥈", "🥉").getOrElse(i) { "🏅" }} رتبه ${i + 1}: $n\n🎁 ${rewards.getOrNull(i).orEmpty().ifBlank { prizes.getOrNull(i).orEmpty().ifBlank { "بدون جایزه" } }}"
            }.joinToString("\n\n")
            if (removeWinner) { names.removeAll(selected.toSet()); nameInput.setText(names.joinToString("\n")) }
            forcedWinner = null
            afterWin()
        }
    }

    private fun animateToWinner(winner: String, onFinished: () -> Unit) {
        val index = names.indexOf(winner)
        if (index < 0) { toast("این اسم دیگر در فهرست نیست."); return }
        spinning = true
        spinButton.isEnabled = false
        val step = 360f / names.size
        val desired = ((-(index + 0.5f) * step) % 360f + 360f) % 360f
        val current = ((wheelAngle % 360f) + 360f) % 360f
        val delta = ((desired - current + 360f) % 360f) + spinRounds * 360f
        val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = spinDuration.toLong()
            interpolator = DecelerateInterpolator(2.2f)
            addUpdateListener {
                val t = it.animatedValue as Float
                wheelAngle = current + delta * t
                wheelView.rotationDegrees = wheelAngle
                wheelView.invalidate()
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    wheelAngle = desired
                    wheelView.rotationDegrees = wheelAngle
                    wheelView.invalidate()
                    spinning = false
                    spinButton.isEnabled = true
                    onFinished()
                }
                override fun onAnimationCancel(animation: Animator) {
                    spinning = false; spinButton.isEnabled = true
                }
            })
        }
        animator.start()
    }

    private fun addHistory(name: String, rank: Int, prize: String) {
        history.add(0, HistoryEntry(name, rank, prize, System.currentTimeMillis(), rounds + 1))
        rounds++
    }

    @Suppress("DEPRECATION")
    private fun afterWin() {
        saveData(); refreshUi(); renderHistory()
        if (vibrationEnabled) {
            try {
                val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
                if (android.os.Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(120, 100))
                else vibrator.vibrate(120)
            } catch (_: Exception) {}
        }
        if (confettiEnabled) {
            // A native visual celebration without external libraries.
            resultText.animate().scaleX(1.035f).scaleY(1.035f).setDuration(150).withEndAction {
                resultText.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
            }.start()
        }
        toast("نتیجه با موفقیت ثبت شد.")
    }

    private fun capturePrizes() {
        for (i in 0..2) {
            prizes[i] = prizeInputs[i].text.toString().trim().ifBlank { "جایزه نفر ${i + 1}" }
            rewards[i] = rewardInputs[i].text.toString().trim()
        }
    }

    private fun refreshUi() {
        if (!::wheelView.isInitialized) return
        wheelView.names = names.toList()
        wheelView.palette = palette()
        wheelView.rotationDegrees = wheelAngle
        wheelView.invalidate()
        statusText.text = when {
            forcedWinner != null -> "🎯 برنده از قبل تعیین شده: $forcedWinner"
            names.isEmpty() -> "اسم‌ها را وارد کن و قرعه‌کشی را شروع کن."
            else -> "${names.size} شرکت‌کننده · ${if (removeWinner) "حذف برنده فعال" else "حذف برنده غیرفعال"}"
        }
        statsText.text = "شرکت‌کننده‌ها: ${names.size}     برنده‌های ثبت‌شده: ${history.size}     دورها: $rounds"
        spinButton.isEnabled = names.isNotEmpty() && !spinning
    }

    private fun renderHistory() {
        if (!::root.isInitialized) return
        val container = findHistoryContainer(root) ?: return
        container.removeAllViews()
        if (history.isEmpty()) {
            container.addView(label("هنوز نتیجه‌ای ثبت نشده است.", 12f, 0xFFADB5D4.toInt()).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(20), 0, dp(20))
            })
            return
        }
        history.take(30).forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(10), dp(10), dp(10))
                background = rounded(0xFF101327.toInt(), 0xFF2D3453.toInt(), 12)
            }
            val rankIcon = label(when (item.rank) { 1 -> "🥇"; 2 -> "🥈"; 3 -> "🥉"; else -> "🏆" }, 20f, -1)
            row.addView(rankIcon, LinearLayout.LayoutParams(dp(38), -2))
            val textColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            textColumn.addView(label(item.name, 14f, -1, true))
            val date = SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.getDefault()).format(Date(item.time))
            textColumn.addView(label("رتبه ${item.rank} · ${item.prize} · $date", 10f, 0xFFADB5D4.toInt()))
            row.addView(textColumn, LinearLayout.LayoutParams(0, -2, 1f))
            val rowParams = LinearLayout.LayoutParams(-1, -2); rowParams.topMargin = dp(6)
            container.addView(row, rowParams)
        }
    }

    private fun showHistoryDialog() {
        val lines = if (history.isEmpty()) "تاریخچه خالی است." else history.joinToString("\n\n") {
            "${it.name} — رتبه ${it.rank}\n${it.prize}\n${SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()).format(Date(it.time))}"
        }
        AlertDialog.Builder(this).setTitle("تاریخچه کامل").setMessage(lines)
            .setPositiveButton("بستن", null).setNeutralButton("خروجی CSV") { _, _ -> exportCsv() }.show()
    }

    private fun exportCsv() {
        if (history.isEmpty()) { toast("تاریخچه خالی است."); return }
        val csv = buildString {
            append("\uFEFFنام برنده,رتبه,جایزه,زمان,دور\n")
            history.forEach {
                val date = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(it.time))
                append(listOf(it.name, it.rank.toString(), it.prize, date, it.round.toString())
                    .joinToString(",") { value -> "\"${value.replace("\"", "\"\"")}\"" })
                append('\n')
            }
        }
        val filename = "lucky-wheel-history-${System.currentTimeMillis()}.csv"
        try {
            val intent = android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(android.content.Intent.CATEGORY_OPENABLE)
                type = "text/csv"
                putExtra(android.content.Intent.EXTRA_TITLE, filename)
            }
            pendingCsv = csv
            startActivityForResult(intent, 271)
        } catch (_: Exception) {
            AlertDialog.Builder(this).setTitle("خروجی CSV").setMessage(csv.take(3500))
                .setPositiveButton("باشه", null).show()
        }
    }

    private var pendingCsv: String? = null
    @Deprecated("Deprecated in Android API but works across the supported Android versions")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 271 && resultCode == RESULT_OK && data?.data != null) {
            try {
                contentResolver.openOutputStream(data.data!!)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(pendingCsv ?: "") }
                toast("فایل تاریخچه ذخیره شد.")
            } catch (e: Exception) { toast("ذخیره فایل ناموفق بود.") }
        }
        pendingCsv = null
    }

    private fun clearHistory() {
        if (history.isEmpty()) { toast("تاریخچه خالی است."); return }
        AlertDialog.Builder(this).setTitle("پاک‌کردن تاریخچه")
            .setMessage("همه نتایج ذخیره‌شده پاک شوند؟")
            .setNegativeButton("انصراف", null)
            .setPositiveButton("پاک شود") { _, _ ->
                history.clear(); rounds = 0; saveData(); refreshUi(); renderHistory(); toast("تاریخچه پاک شد.")
            }.show()
    }

    private fun saveData() {
        val jsonHistory = JSONArray()
        history.forEach { h ->
            jsonHistory.put(JSONObject().put("name", h.name).put("rank", h.rank).put("prize", h.prize).put("time", h.time).put("round", h.round))
        }
        val jsonPrizes = JSONArray(); prizes.forEach { jsonPrizes.put(it) }
        val jsonRewards = JSONArray(); rewards.forEach { jsonRewards.put(it) }
        prefs.edit()
            .putString("names", names.joinToString("\n"))
            .putString("history", jsonHistory.toString())
            .putString("prizes", jsonPrizes.toString())
            .putString("rewards", jsonRewards.toString())
            .putInt("rounds", rounds)
            .putFloat("angle", wheelAngle)
            .putBoolean("removeWinner", removeWinner)
            .putInt("spinRounds", spinRounds)
            .putInt("spinDuration", spinDuration)
            .putString("forcedWinner", forcedWinner)
            .putInt("themeChoice", themeChoice)
            .putBoolean("vibrationEnabled", vibrationEnabled)
            .putBoolean("confettiEnabled", confettiEnabled)
            .apply()
    }

    private fun loadData() {
        names.clear()
        names.addAll(prefs.getString("names", "").orEmpty().split(Regex("\\r?\\n")).map { it.trim() }.filter { it.isNotEmpty() }.distinct())
        history.clear()
        try {
            val arr = JSONArray(prefs.getString("history", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                history.add(HistoryEntry(o.optString("name"), o.optInt("rank", 1), o.optString("prize"), o.optLong("time"), o.optInt("round", 1)))
            }
        } catch (_: Exception) {}
        try {
            val p = JSONArray(prefs.getString("prizes", "[]"))
            for (i in 0 until min(3, p.length())) prizes[i] = p.optString(i, prizes[i])
        } catch (_: Exception) {}
        try {
            val r = JSONArray(prefs.getString("rewards", "[]"))
            for (i in 0 until min(3, r.length())) rewards[i] = r.optString(i, rewards[i])
        } catch (_: Exception) {}
        rounds = prefs.getInt("rounds", history.size)
        wheelAngle = prefs.getFloat("angle", 0f)
        removeWinner = prefs.getBoolean("removeWinner", true)
        spinRounds = prefs.getInt("spinRounds", 8).coerceIn(3, 20)
        spinDuration = prefs.getInt("spinDuration", 5200).coerceIn(2500, 12500)
        forcedWinner = prefs.getString("forcedWinner", null)
        themeChoice = prefs.getInt("themeChoice", 0).coerceIn(0, 3)
        vibrationEnabled = prefs.getBoolean("vibrationEnabled", true)
        confettiEnabled = prefs.getBoolean("confettiEnabled", true)
    }

    private fun findHistoryContainer(view: View): LinearLayout? {
        if (view is LinearLayout && view.tag == "historyContainer") return view
        if (view is ViewGroup) for (i in 0 until view.childCount) {
            val found = findHistoryContainer(view.getChildAt(i))
            if (found != null) return found
        }
        return null
    }

    private fun palette(): IntArray = when (themeChoice) {
        1 -> intArrayOf(0xFF00BFA5.toInt(),0xFF26C6DA.toInt(),0xFF80CBC4.toInt(),0xFF4DB6AC.toInt(),0xFF4FC3F7.toInt(),0xFF64FFDA.toInt())
        2 -> intArrayOf(0xFFFF7043.toInt(),0xFFFFCA28.toInt(),0xFFEF5350.toInt(),0xFFFFA726.toInt(),0xFFFFD54F.toInt(),0xFFEC407A.toInt())
        3 -> intArrayOf(0xFFEC407A.toInt(),0xFFAB47BC.toInt(),0xFFFF80AB.toInt(),0xFF7E57C2.toInt(),0xFFF06292.toInt(),0xFFBA68C8.toInt())
        else -> intArrayOf(0xFF7957D5.toInt(),0xFF4169E1.toInt(),0xFF00A8A8.toInt(),0xFFE85D75.toInt(),0xFFFFA62B.toInt(),0xFF6C63FF.toInt())
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(15), dp(15), dp(15))
        background = rounded(0xFF171A30.toInt(), 0xFF303653.toInt(), 20)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(14)
        layoutParams = lp
    }
    private fun sectionTitle(text: String): TextView = label(text, 16f, -1, true).apply { setPadding(0, 0, 0, dp(7)) }
    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER_VERTICAL; textDirection = View.TEXT_DIRECTION_RTL
    }
    private fun horizontalRow(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        val lp = LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(10); layoutParams = lp
    }
    private fun weighted(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(6) }
    private fun button(text: String, color: Int, action: () -> Unit): Button = Button(this).apply {
        this.text = text; textSize = 12f; isAllCaps = false; setTextColor(if (color == 0xFFFFB94E.toInt()) 0xFF281D20.toInt() else -1)
        background = rounded(color, color, 12); minHeight = dp(44); setPadding(dp(8), dp(3), dp(8), dp(3))
        setOnClickListener { action() }
    }
    private fun rounded(color: Int, stroke: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), stroke) }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private data class HistoryEntry(val name: String, val rank: Int, val prize: String, val time: Long, val round: Int)

    inner class WheelView(context: Context) : View(context) {
        var names: List<String> = emptyList()
        var palette: IntArray = intArrayOf()
        var rotationDegrees = 0f
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val bounds = RectF()
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val side = min(width, height).toFloat()
            val cx = width / 2f; val cy = height / 2f
            val radius = side * .465f
            paint.style = Paint.Style.FILL
            paint.color = 0xFFFFD66B.toInt()
            canvas.drawCircle(cx, cy, radius + dp(5), paint)
            paint.color = 0xFF292340.toInt()
            canvas.drawCircle(cx, cy, radius, paint)
            if (names.isEmpty()) {
                paint.color = 0xFFADB5D4.toInt(); paint.textAlign = Paint.Align.CENTER; paint.textSize = dp(15).toFloat()
                canvas.drawText("اسم‌ها را وارد کن", cx, cy, paint); return
            }
            val step = 360f / names.size
            bounds.set(cx-radius, cy-radius, cx+radius, cy+radius)
            for (i in names.indices) {
                val start = -90f + rotationDegrees + i * step
                paint.color = palette[i % palette.size]
                paint.style = Paint.Style.FILL
                canvas.drawArc(bounds, start, step, true, paint)
                paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(2).toFloat(); paint.color = 0xFF19172B.toInt()
                canvas.drawArc(bounds, start, step, true, paint)
                paint.style = Paint.Style.FILL
                val mid = Math.toRadians((start + step/2).toDouble())
                val textRadius = radius * .65f
                val x = cx + cos(mid).toFloat() * textRadius
                val y = cy + sin(mid).toFloat() * textRadius
                canvas.save()
                canvas.rotate((start + step/2 + 90f), x, y)
                paint.color = -1; paint.textAlign = Paint.Align.CENTER; paint.typeface = Typeface.create("sans-serif", Typeface.BOLD)
                paint.textSize = when { names.size > 30 -> dp(9).toFloat(); names.size > 18 -> dp(10).toFloat(); names.size > 10 -> dp(12).toFloat(); else -> dp(14).toFloat() }
                val maxLength = when { names.size > 24 -> 8; names.size > 14 -> 11; else -> 16 }
                val txt = if (names[i].length > maxLength) names[i].take(maxLength-1) + "…" else names[i]
                canvas.drawText(txt, x, y, paint)
                canvas.restore()
            }
            paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(4).toFloat(); paint.color = 0xFFFFF0B7.toInt()
            canvas.drawCircle(cx, cy, radius, paint)
            // Fixed top pointer.
            paint.style = Paint.Style.FILL; paint.color = 0xFFFFE7A0.toInt()
            val pointer = Path().apply {
                moveTo(cx - dp(14), cy - radius - dp(5))
                lineTo(cx + dp(14), cy - radius - dp(5))
                lineTo(cx, cy - radius + dp(22))
                close()
            }
            canvas.drawPath(pointer, paint)
        }
    }
}
